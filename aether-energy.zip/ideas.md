# Aether Energy — Design Brainstorm

## Context
Aether Energy is an AI-powered no-code oil trading platform targeting institutional and sophisticated traders. The brand name "Aether" evokes the classical element — ethereal, invisible yet powerful, connecting everything. The product is about intelligence, precision, and democratizing access to institutional-grade tools.

---

<response>
<text>
## Idea 1: "Refined Brutalism" — Dark Industrial Precision

**Design Movement:** Industrial Brutalism meets Fintech Minimalism

**Core Principles:**
- Raw, unapologetic typography with extreme weight contrast
- Monochromatic base with a single high-voltage accent (amber/gold for oil/energy)
- Asymmetric layouts with deliberate tension — content blocks that feel "loaded"
- Data-forward aesthetic: numbers, charts, and metrics as visual decoration

**Color Philosophy:**
- Background: Near-black (#0A0A0B) — the color of crude oil
- Primary text: Off-white (#F5F0E8) — aged parchment, institutional gravitas
- Accent: Amber-gold (#D4A017) — liquid gold, oil, wealth
- Secondary accent: Electric teal (#00D4AA) — AI/data streams
- Muted: Dark slate (#1C1C22)

**Layout Paradigm:**
- Full-bleed sections with hard-edge cuts (no rounded corners on major blocks)
- Left-aligned hero with large numerical counters as visual anchors
- Staggered card grids that break the 12-column rule
- Sticky side-rail navigation with section indicators

**Signature Elements:**
- Oversized section numbers (01, 02, 03) as structural dividers
- Thin horizontal rules with amber glow
- Terminal-style monospace data readouts alongside serif headlines

**Interaction Philosophy:**
- Hover states reveal hidden data layers
- Scroll-triggered counter animations for KPI numbers
- Cursor-tracking subtle parallax on hero background

**Animation:**
- Entrance: elements slide in from left with slight opacity fade
- Numbers count up on viewport entry
- Subtle oil-drop particle effect in hero background

**Typography System:**
- Display: Bebas Neue (ultra-condensed, industrial)
- Body: DM Sans (clean, modern, readable)
- Mono: JetBrains Mono (data/code elements)
</text>
<probability>0.08</probability>
</response>

<response>
<text>
## Idea 2: "Aetheric Depth" — Dark Cosmos with Liquid Intelligence

**Design Movement:** Cosmic Minimalism meets Bloomberg Terminal Elegance

**Core Principles:**
- Deep space aesthetic — darkness as sophistication, not absence
- Luminous data visualization as decorative elements
- Fluid, organic shapes contrasting with rigid data grids
- Premium feel through restraint: less is more, every element earns its place

**Color Philosophy:**
- Background: Deep navy-black (#050B18) — the deep ocean, the cosmos
- Primary: Crisp white (#FFFFFF) — clarity and precision
- Accent 1: Electric blue (#2563EB) — intelligence, technology, trust
- Accent 2: Petroleum amber (#F59E0B) — oil, energy, value
- Glow effects: Soft cyan (#06B6D4) — AI data streams
- Gradient: Deep navy → midnight blue for section transitions

**Layout Paradigm:**
- Asymmetric split hero: 60/40 text-to-visual ratio
- Floating card components with glassmorphism (subtle backdrop blur)
- Diagonal section dividers suggesting momentum and forward motion
- Full-width feature strips alternating text-left / visual-right

**Signature Elements:**
- Animated candlestick chart in hero background (subtle, ghosted)
- Glassmorphism cards with thin luminous borders
- Flowing gradient mesh backgrounds for key sections

**Interaction Philosophy:**
- Cards lift with depth shadow on hover
- Smooth scroll with section snap points
- Animated gradient borders on CTA buttons

**Animation:**
- Hero: staggered text reveal with blur-to-sharp transition
- Features: cards cascade in from bottom on scroll
- Stats: number counters with easing curves
- Background: slow-drifting gradient mesh

**Typography System:**
- Display: Syne (geometric, futuristic, distinctive)
- Body: Inter (reliable, clean)
- Accent: Space Mono (data readouts, prices)
</text>
<probability>0.07</probability>
</response>

<response>
<text>
## Idea 3: "Elemental Precision" — Dark Slate with Amber Veins

**Design Movement:** Swiss International Style meets Energy Sector Gravitas

**Core Principles:**
- Grid-breaking asymmetry with mathematical precision
- Amber/gold as the "element" — oil, energy, intelligence converging
- Typography as architecture — headlines that structure space
- Contrast between cold steel (dark backgrounds) and warm gold (accents)

**Color Philosophy:**
- Background: Charcoal slate (#0F1117) — refined darkness
- Surface: Dark graphite (#161B27) — card backgrounds
- Primary accent: Warm amber (#E8A020) — oil, gold, energy
- Secondary: Cool steel blue (#3B82F6) — AI, data, technology
- Text: Near-white (#EEF2F7) for primary, steel grey (#8B9BB4) for secondary
- Border: Subtle amber glow (#E8A020 at 20% opacity)

**Layout Paradigm:**
- Vertical rhythm with generous line-height
- Hero with large display type and a live-updating mock price ticker
- Feature sections using a masonry-style card layout
- Pricing section with a prominent "recommended" card that breaks the grid

**Signature Elements:**
- Thin amber horizontal rules as section separators
- Oil barrel / molecular hexagon motifs as decorative geometry
- Glowing amber CTA buttons with a subtle pulse animation

**Interaction Philosophy:**
- Hover: amber glow spreads from cursor contact point
- Scroll: sections fade up with slight Y-translation
- CTA buttons: shimmer effect on hover

**Animation:**
- Hero: text lines stagger in with 80ms delays
- Feature cards: rotate slightly (2deg) then settle on hover
- Price ticker: smooth horizontal scroll loop
- Background: very subtle noise texture overlay

**Typography System:**
- Display: Clash Display (bold, geometric, premium)
- Body: Satoshi (modern, clean, excellent readability)
- Data: Space Grotesk (technical, precise)
</text>
<probability>0.09</probability>
</response>

---

## Selected Design: **Idea 3 — "Elemental Precision"**

Chosen for its balance of institutional gravitas and energy-sector identity. The amber/gold accent directly references oil and wealth, while the dark slate background conveys the sophistication expected by institutional traders. The Swiss grid-breaking asymmetry prevents the "AI slop" look while the warm/cool contrast creates visual tension that keeps users engaged.
